const os = require('os');
const fs = require('fs');

const computerSpecs = `host: ${os.hostname()}
plataforma: ${os.platform()}
procesador: ${os.cpus()[0].model}
arquitectura: ${os.arch()}
memoria en total en bytes: ${os.totalmem()} bytes`;

fs.writeFileSync('caracteristicas.txt', computerSpecs);
console.log('Se ha generado el archivo con las carecteristicas');
s